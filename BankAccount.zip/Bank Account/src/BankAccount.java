import java.util.ArrayList;

public class BankAccount {
    private String accountNumber;
    private String password;
    private double balance;
    private ArrayList<String> transactionHistory;
    private boolean accountLock;

    public BankAccount(String accountNumber, String password, double balance) {
        this.accountNumber = accountNumber;
        this.password = password;
        this.balance = balance;
        this.transactionHistory = new ArrayList<>();
        this.accountLock = true;
    }

    public void printTransactionHistory() {
        if (!accountLock) {
            System.out.println("Account is locked! Can not perform any actions!");
            return;
        }

        System.out.println("Transaction History for Account: " + accountNumber);
        if (transactionHistory.isEmpty()) {
            System.out.println("Transaction is not available.");
            return;
        }

        for (String transaction : transactionHistory) {
            if (transaction != null) {
                System.out.println(transaction);
            }
        }
    }

    public boolean transferMoney(BankAccount recipient, double amount) {
        if (!accountLock) {
            System.out.println("Account is locked. Cannot perform any actions.");
            return false;
        }

        if (amount > 1000) {
            System.out.println("Transfer amount exceeds the limit of $1000.");
            return false;
        }

        if (amount > balance) {
            System.out.println("Insufficient balance for the transfer.");
            return false;
        }

        this.balance -= amount;
        recipient.balance += amount;

        String transaction = "Transferred $" + amount + " to account " + recipient.accountNumber;
        this.transactionHistory.add(transaction);
        recipient.transactionHistory.add("Received $" + amount + " from account " + this.accountNumber);

        System.out.println(transaction);
        return true;
    }

    public void lockAccount() {
        this.accountLock = false;
        System.out.println("Account has been locked!");
    }

    public void unlockAccount() {
        this.accountLock = true;
        System.out.println("Account has been unlocked!");
    }

    public double calculateDeposit(double amount, int months) {
        if (!accountLock) {
            System.out.println("Account is locked. Cannot perform any actions.");
            return 0;
        }

        double finalAmount = amount;
        for (int i = 0; i < months; i++) {
            finalAmount += finalAmount * 0.01;
        }
        return finalAmount;
    }
}