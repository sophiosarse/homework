public class Main {
    public static void main(String[] args) {
        BankAccount account1 = new BankAccount("123456789", "Pass123", 1500);
        BankAccount account2 = new BankAccount("987654321", "Pass321", 500);

        account1.printTransactionHistory();

        account1.transferMoney(account2, 300);
        account1.transferMoney(account2, 1200);
        account1.transferMoney(account2, 200);
        System.out.println();

        account1.printTransactionHistory();
        account2.printTransactionHistory();
        System.out.println();

        account1.lockAccount();
        account1.transferMoney(account2, 100);
        System.out.println();

        account1.unlockAccount();
        account1.transferMoney(account2, 100);
        System.out.println();

        double finalAmount = account1.calculateDeposit(1000, 10);
        System.out.println("Final amount: $" + finalAmount);
    }
}